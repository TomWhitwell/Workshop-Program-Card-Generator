## Inkscape Instructions 

- `Inkscape-program-card-template.svg` is 19 mm wide × 11 mm tall.
- It contains four layers: PCB, OUTLINE, SAFETY and CONTENT.
- CONTENT is a suggested layer for your design, not a requirement. Artwork on any visible layer is included.
- Hide or delete the PCB, OUTLINE and SAFETY guide layers before saving. Otherwise those reference shapes will also become artwork on the card.
- SAFETY shows the approximate copper area. Artwork outside the 19 × 11 mm page is clipped; artwork outside the copper area may not be visible on the finished card.
- The colour of your artwork is irrelevant—it will all appear as gold on the cards.
- Convert live text to paths with **Path → Object to Path**.
- Convert strokes to filled paths with **Path → Stroke to Path**. Filled paths and standard SVG shapes are the most reliable input.
- Save the design as **Plain SVG**, then upload it at https://pcg.musicthing.co.uk/.
- The upload page checks common problems before starting and shows a specific correction if the converter cannot process something.
