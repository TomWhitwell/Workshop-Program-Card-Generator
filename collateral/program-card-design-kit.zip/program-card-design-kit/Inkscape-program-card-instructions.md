## Inskscape Instructions 

- I'm not very experiences at Inkscape, so there may be better ways to do this. Report any issues to tom@musicthing.co.uk. 
- Inkscape-program-card-template.svg is a small file - 19mm wide 11mm tall 
- It contains four layers: PCB, OUTLINE, SAFTEY and CONTENT 
- Put your artwork in Content. The other layers show the space left to create your design. SAFETY shows the approximate outline of the copper layer, any artwork outside this will be invisible 
- The colour of your artwork is irrelevant - it’s all gold on the cards 
- Important: The SVG to PCB process is quite crude, particularly for Inkscape files. Convert all text to paths (Path/Object to Path). Convert strokes to path if you want unfilled shapes (Path/Stroke to Path) - although you may need to experiment a bit to get what you're looking for. 
 - Once you’re happy with your design, turn off the PCB, Card_Outline and Card_Safety layers. 
- Then go to File/Save As and save your SVG as 'Plain SVG'.
- Now to to https://pcg.musicthing.co.uk/ and turn your design into PCB files. 